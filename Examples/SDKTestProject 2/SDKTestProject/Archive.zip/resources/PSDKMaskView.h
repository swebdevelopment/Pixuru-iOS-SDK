//
//  PSDKMaskView.h
//  PixuruSDK
//
//  Created by Skyler Whittlesey on 10/7/13.
//  Copyright (c) 2013 Skyler Whittlesey. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PSDKMaskView : UIView

@end
