//
//  PSDKCancelButton.h
//  PixuruSDK
//
//  Created by Skyler Whittlesey on 10/17/13.
//  Copyright (c) 2013 Skyler Whittlesey. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PSDKCancelButton : UIButton

@end
